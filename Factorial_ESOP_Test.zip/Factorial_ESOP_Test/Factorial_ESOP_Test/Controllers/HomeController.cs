﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using Factorial_ESOP_Test.Models;

namespace Factorial_ESOP_Test.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(FactorialModel model)
        {
            int count = 1, number = 1, factorialNumber;
            double factorial=1;
           
                factorialNumber = Convert.ToInt32(model.Number);
                if (factorialNumber > 0)
                {

                    while (count <= factorialNumber)
                    {
                        factorial = factorial * number;
                        count++;
                        number++;
                    }
                    model.ResultText = "Result is:";
                    model.Result = factorial.ToString();

                    //Log Management

                    StreamWriter sw = new StreamWriter(Server.MapPath("~/ResultLog.txt"), true);
                    sw.WriteLine(DateTime.Now + " : Factorial of " + factorialNumber + " is:" + factorial);
                    sw.Close();

                }
                else
                {
                    model.ResultText = "Please enter postive number.";
                    model.Result = "";
                }
                return View(model);
            
            
        }
	}
}