﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Factorial_ESOP_Test.Models
{
    public class FactorialModel
    {
        public double Number
        {
            get;
            set;
        }
        public string Result
        {
            get;
            set;
        }
        public string ResultText
        {
            get;
            set;
        }
    }
}